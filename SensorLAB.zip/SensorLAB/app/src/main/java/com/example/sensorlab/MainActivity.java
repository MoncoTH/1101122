package com.example.sensorlab;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    SensorManager sm = null;
    TextView textView1 = null;
    List list;

    SensorEventListener sel = new SensorEventListener(){
        public void onAccuracyChanged(Sensor sensor, int accuracy) {}
        public void onSensorChanged(SensorEvent event) {
            float[] values = event.values;
            if (values[0] >= -1.31){
                textView1.setText( "Values of Gravity" + "\nx: "+values[0]+"\ny: "+values[1]+"\nz: "+values[2]);
            }
            if (values[0] >= 1.07){
                textView1.setText( "Values of Gyroscope" + "\nx: "+values[0]+"\ny: "+values[1]+"\nz: "+values[2]);
            }
            if (values[0] <= -1.31){
                textView1.setText( "Values of Gravity" + "\nx: "+values[0]+"\ny: "+values[1]+"\nz: "+values[2]);
            }
            if (values[0] >= -33.6875){
                textView1.setText( "Values of Magnetic" + "\nx: "+values[0]+"\ny: "+values[1]+"\nz: "+values[2]);
            }
        }
    };


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /* Get a SensorManager instance */
        sm = (SensorManager)getSystemService(SENSOR_SERVICE);

        textView1 = (TextView)findViewById(R.id.textView1);
        list = sm.getSensorList(Sensor.TYPE_ACCELEROMETER);
        if(list.size()>0){
            sm.registerListener(sel, (Sensor) list.get(0), SensorManager.SENSOR_DELAY_NORMAL);
        }else{
            Toast.makeText(getBaseContext(), "Error: No Accelerometer.", Toast.LENGTH_LONG).show();
        }

    }

    @Override
    protected void onStop() {
        if(list.size()>0){
            sm.unregisterListener(sel);
        }
        super.onStop();
    }
}